module.exports = {
    JWT_SECRET: 'your_jwt_secret_here',
  };
  