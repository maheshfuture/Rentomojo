import React, { useState } from 'react';
import './styles.css';
import CommentForm from './components/CommentForm';
import CommentList from './components/CommentList';

function App() {
  const [comments, setComments] = useState([]);

  const handleCommentSubmit = (newComment) => {
    setComments([...comments, newComment]);
  };

  const handleLike = (index) => {
    const updatedComments = [...comments];
    updatedComments[index].likes++;
    setComments(updatedComments);
  };

  const handleDislike = (index) => {
    const updatedComments = [...comments];
    updatedComments[index].dislikes++;
    setComments(updatedComments);
  };

  return (
    <div className="App">
      <h1>Commenting System</h1>
      <CommentForm onCommentSubmit={handleCommentSubmit} />
      <CommentList
        comments={comments}
        onLike={handleLike}
        onDislike={handleDislike}
      />
    </div>
  );
}

export default App;
