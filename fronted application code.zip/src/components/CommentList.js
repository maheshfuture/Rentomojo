import React from 'react';

const CommentList = ({ comments, onLike, onDislike }) => {
  return (
    <div className="comment-list">
      {comments.map((comment, index) => (
        <div key={index} className="comment">
          <p>{comment.text}</p>
          <button onClick={() => onLike(index)}>Like</button>
          <button onClick={() => onDislike(index)}>Dislike</button>
          <p>Likes: {comment.likes}</p>
          <p>Dislikes: {comment.dislikes}</p>
        </div>
      ))}
    </div>
  );
};

export default CommentList;
