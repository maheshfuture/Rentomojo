import React, { useState } from 'react';

const CommentForm = ({ onCommentSubmit }) => {
  const [commentText, setCommentText] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (commentText.trim() === '') return;

    const newComment = {
      text: commentText,
      likes: 0,
      dislikes: 0,
    };

    onCommentSubmit(newComment);
    setCommentText('');
  };

  return (
    <div className="comment-form">
      <form onSubmit={handleSubmit}>
        <textarea
          placeholder="Write a comment..."
          value={commentText}
          onChange={(e) => setCommentText(e.target.value)}
        />
        <button type="submit">Post Comment</button>
      </form>
    </div>
  );
};

export default CommentForm;
